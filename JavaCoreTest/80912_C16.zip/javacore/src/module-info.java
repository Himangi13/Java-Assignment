/**
 * 
 */
/**
 * 
 */
module javacoreTest {
}